/* 
 * File:   Ga9EdC4P1
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: The date June 10, 1960 
 * is special because when we write 
 * it in the following format, the 
 * month times the day equals the year.
 * 6/10/60
 * Write a program that asks the user to 
 * enter a month (in numeric form), a day, 
 * and a two-digit year. The program should 
 * then determine whether the month times the 
 * day is equal to the year. If so, it should 
 * display a message say the date is magic. 
 * Otherwise, it should display a message saying 
 * the is not magic.
 * Answer will either be "The date is magic" or 
 * "The date is not magic"
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    unsigned int day, mnth, yr; 
    
    cout << "Enter a month:\n";
    cin>>mnth;
    cout << "Enter a day:\n";
    cin>>day;
    cout << "Enter a year:\n";
    cin>>yr;
    
    if (mnth*day==yr)cout << "The date is magic";
    else cout << "The date is not magic"; 
    
    //Initialize Variables
    
    
    
    //Process or map Inputs to Outputs
    
    //Display Outputs

    //Exit stage right!
    return 0;
}