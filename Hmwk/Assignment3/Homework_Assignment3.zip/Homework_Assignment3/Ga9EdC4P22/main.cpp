/* 
 * File:   Ga9EdC4P22
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: The following table lists 
 * the freezing and boiling points of 
 * several substances. Write a program 
 * that asks the user to enter a temperature 
 * then shows all substances that will 
 * freeze at that temperature, and all 
 * that will boil at that temperature. 
 * For example, if the user enters -20, 
 * the program should report that water 
 * will freeze and oxygen will boil at that 
 * temperature.
 * Substance:       Freezing Point (ºF):        Boiling Point (ºF):
 * Ethyl Alcohol:           -173                        172
 * Mercury:                 -38                         676
 * Oxygen:                  -362                        -306
 * Water:                    32                         212
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    float input, ethbp, ethfp, merbp, merfp, oxybp, oxyfp, waterbp, waterfp; 
    
    ethfp = -173;
    ethbp = 172;
    merfp = -38;
    merbp = 676;
    oxyfp = -362;
    oxybp = -306;
    waterfp = 32;
    waterbp = 212;
    
    cout << "Enter a temperature:" << endl;
    cin>>input;
    
    if (input <= ethfp) 
    {cout << "Ethyl alcohol will freeze\n";}
    
    if (input <= merfp) 
    {cout << "Mercury will freeze\n";}
    
    if (input <= oxyfp) 
    {cout << "Oxygen will freeze\n";}
    
    if (input <= waterfp) 
    {cout << "Water will freeze\n";}
    
    if (input >= ethbp) 
    {cout << "Ethyl alcohol will boil\n";}
    
    if (input >= merbp) 
    {cout << "Mercury will boil\n";}
    
    if (input >= oxybp) 
    {cout << "Oxygen will boil\n";}
    
    if (input >= waterbp) 
    {cout << "Water will boil\n";}
    
    
    
    
    //Exit stage right!
    return 0;
}