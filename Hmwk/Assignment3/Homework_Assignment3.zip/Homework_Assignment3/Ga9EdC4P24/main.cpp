/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: destr
 *
 * Created on January 21, 2020, 8:28 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    float under7, under19, under24;
    float inputtime, minutes, amountowed;
    int copytime;
    bool valid;
    
    
    under7 <=06.59;
    under19 <=19.00;
    under24 <=23.59;
    
    
    cout << "Enter the starting time:\n";
    cin>>inputtime;
    valid=(inputtime<=23.59);
    if (!valid)cout<<"Error";
    
    while (valid){
    cout << "Enter the minutes of the call:\n";
    cin>>minutes;
    copytime=minutes/10+inputtime;
    
    
    if (copytime<=under7)
    { 
        cout<<"The charges are " << copytime*0.05;
    }
    
    if (copytime<=under19)
    {
        cout<<"The charges are " << copytime*0.45;
    }
    
    if (copytime<=under24)
    {
        cout<<"The charges are " << copytime*0.20;
    }
    
    else if (inputtime-copytime>0.59)
    {
        cout<< "Time Exceeded";
    }
    }
    

    return 0;
}