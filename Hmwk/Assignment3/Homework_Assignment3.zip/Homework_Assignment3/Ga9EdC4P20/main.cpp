/* 
 * File:   Ga9EdC4P20
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: The following table shows 
 * the approximate speed of sound in air, water, and steel.
 * Air:     1100 feet per second
 * Water:   4900 feet per second
 * Steel:   16400 feet per second
Write a program that displays a menu allowing 
 * the user to select air, water, or steel. 
 * After the user has made a selection, he or she 
 * should be asked to enter the distance a sound wave 
 * will travel in the selected medium. The program 
 * will then display the amount of time it will take. 
 * (Round the answer to four decimal places.)
 * Input Validation: Check that the user has selected 
 * one of the available choices from the menu. Do not 
 * accept distances less than 0.
 */

//System Libraries
#include<iostream>
#include<iomanip> //include iomanip library to format output
using namespace std;

int main()
 {
    //declare variable needed to store user input
    //and output distance
    char material;
    double distance, time;

    //prompt user to enter the environment and
    //the distance the sound will travel.
    cout << "Choose which medium the sound wave will travel in.\n";
    cout << "1.Air\n2.Water\n3.Steel\n";
    cin >> material;

    cout << "Enter the distance the wave will travel:\n";
    cin >> distance;

    //immediately validate only positive distances
    if(distance >= 0){
        switch (material){
            case '1':
                time = (distance / 1100);
                break;
            case '2':
                time = (distance / 4900);
                break;
            case '3':
                time = (distance / 16400);
                break;
            default:
                //display error message for invalid material
                //input
                cout << "Please enter an available environment!\n";
                break;
        }
    }
    else{
        //display error message for negative distances
        cout << "Distances less than 0 are not accepted!\n";
    }

    //display on screen output message
    cout << fixed;
    cout << "The wave will take " << setprecision(4) << time << " seconds";
    
    //return 0 to mark successful completion of program
    return 0;
 }