/* 
 * File:   Ga9EdC4P22
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: Write a program that displays the following menu:
 * Geometry Calculator
 * 1. Calculate the Area of a Circle
 * 2. Calculate the Area of a Rectangle
 * 3. Calculate the Area of a Triangle
 * 4. Quit
 * Enter your choice (1-4):
 * If the user enters 1, the program should ask for the 
 * radius of the circle then display its area. 
 * Use the following formula:
 * area = pi r^2
 * Use 3.14159 for pi and the radius of the circle for r. 
 * If the user enters 2, the program should ask for the 
 * length and width of the rectangle, then display the 
 * rectangle's area. Use the following formula:
 * area = length * width
 * If the user enters 3, the program should ask for 
 * the length of the triangle's base, and its height, 
 * then display its area. Use the following formula:
 * area = base * height * .5
 * If the user enters 4, the program should end.
 * Input Validation: Display an error message if the 
 * user enters a number outside the range of 1 through 4 
 * when selecting an item from the menu. Do not accept 
 * negative values for the circle's radius, the rectangle's 
 * length or width, or the triangle's base or height. 
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    float choice, r, length, width, base, height;
    const int pi = 3.14159;
    const int carea = pi*r*r;
    const int rarea = length*width;
    const int tarea = base*height*0.5;
    int area = carea&&rarea&&tarea;
    
    
    /*while (choice!=1&&choice!=2&&choice!=3&&choice!=4) 
    {
    cout << fixed;
    cout << "Geometry Calculator\n 1. Calculate the Area of a Circle\n 1. Calculate the Area of a Rectangle\n 3. Calculate the Area of a Triangle\n 4. Quit\n";
    cin>>choice;
    }*/
    
    
    if (r<=0&&height<=0&&width<=0&&base<=0&&height<=0)
        cout<<"Invalid entry, Reenter:\n"; 
    {
        
        
        while (choice!=1&&choice!=2&&choice!=3&&choice!=4) 
    {
    cout << fixed;
    cout << "Geometry Calculator\n 1. Calculate the Area of a Circle\n 1. Calculate the Area of a Rectangle\n 3. Calculate the Area of a Triangle\n 4. Quit\n";
    cin>>choice;
    }
        
        
        switch (area)
        {
            case 1: 
            cout << "Enter the radius of the circle:\n";
            cin>>r;
            area = carea;
            cout << "The are of the circle is " << area;
            break;
            case 2:
                cout << "Enter the length of the rectangle:\n";
                cin>>length;
                cout << "Enter the width of the rectangle:\n";
                cin>>width;
                area = rarea;
                break;
            case 3:
            cout << "Enter the base of the triangle:\n";
            cin>>base;
            cout << "Enter the height of the triangle:\n";
            cin>>height;
            area = rarea;
            break;
            case 4: 
            return 0;
            break;
    }
    }
    //Exit stage right!
    return 0;
}