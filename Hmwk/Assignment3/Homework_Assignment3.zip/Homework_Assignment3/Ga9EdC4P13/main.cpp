/* 
 * File:   Ga9EdC4P1
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: Serendipity Booksellers 
 * has a book club that awards points 
 * to its customers based on the number 
 * of books purchased each month. 
 * The points are awarded as follows:
 * If a customer purchases 0 books, he or she earns 0 points.
 * If a customer purchases 1 books, he or she earns 5 points.
 * If a customer purchases 2 books, he or she earns 15 points.
 * If a customer purchases 3 books, he or she earns 30 points.
 * If a customer purchases 4 or more books, he or she earns 60 points.
 * Write a program that asks the user to enter the 
 * number of books he or she has purchased this month 
 * then displays the number of points awarded.
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    float bksprchsd, mnth, pnts; 
    
    cout << "Enter how many books you purchased this month:\n";
    cin>>bksprchsd;
    
    if (bksprchsd==0)cout<<"You earned 0 points.";
    if (bksprchsd==1)cout<<"You earned 5 points.";
    if (bksprchsd==2)cout<<"You earned 15 points.";
    if (bksprchsd==3)cout<<"You earned 30 points.";
    if (bksprchsd>=4)cout<<"You earned 60 points.";
    
    
    

    //Exit stage right!
    return 0;
}