/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 15, 2020, 11:10 AM
 * Purpose:  Arabic Number to Roman Numerals
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variable Data Types and Constants
    unsigned short convert;
    
    //Initialize Variables
    cout<<"Enter a number between 1 and 10:"<<endl;
    
    
    while (convert<1||convert>10)
    {
    cin >>convert;
    if(convert>=1&&convert<=10){
    //Process or map Inputs to Outputs
        //Determine 1000's, 100's, 10's, 1's
        unsigned char tens, ones;
        
        tens = convert/10;
        ones = convert%10;
        
        switch (convert)
    {
        case 1:
            cout << convert << " is I in Roman numerals";
            break;
        case 2:
            cout << convert << " is II in Roman numerals";
            break;
        case 3:
            cout << convert << " is III in Roman numerals";
            break;
        case 4:
            cout << convert << " is IV in Roman numerals";
            break;
        case 5:
            cout << convert << " is V in Roman numerals";
            break;
        case 6:
            cout << convert << " is VI in Roman numerals";
            break;
        case 7:
            cout << convert << " is VII in Roman numerals";
            break;
        case 8:
            cout << convert << " is VIII in Roman numerals";
            break;
        case 9:
            cout << convert << " is IX in Roman numerals";
            break;
        case 10:
            cout << convert << " is X in Roman numerals";
            break;
            
        }
        
        
        //Reiterate the input value
       //The Path to Exit
    }else{
        cout << "Entered number is not valid, reenter number:" << endl;
        
        
    }
    }
    //Exit stage right!
    return 0;
}