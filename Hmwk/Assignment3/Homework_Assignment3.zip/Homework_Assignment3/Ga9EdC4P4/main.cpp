/* 
 * File:   Ga9EdC4P4
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: The area of a 
 * rectangle is the rectangle's 
 * length times its width. 
 * Write a program that asks 
 * for the length and width of 
 * two rectangles. The program 
 * should tell the user which 
 * rectangle has the greater area, 
 * or if the area's are the same.
 * Answer should be either 
 * "Rectangle 1 has the greater area" 
 * or "The rectangles have the same area"
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    int rct1w, rct1h, rct1a, rct2w, rct2h, rct2a; 
    
    cout << "Enter the width of rectangle 1:\n";
    cin>>rct1w;
    cout << "Enter the height of rectangle 1:\n";
    cin>>rct1h;
    cout << "Enter the width of rectangle 2:\n";
    cin>>rct2w;
    cout << "Enter the height of rectangle 2:\n";
    cin>>rct2h; 
    
    rct1a=rct1w*rct1h;
    rct2a=rct2w*rct2h;
    
    if (rct1a>rct2a)cout << "Rectangle 1 has the greater area";
    if (rct1a==rct2a)cout << "The rectangles have the same area";
    if (rct1a<rct2a)cout << "Rectangle 2 has the greater area"; 
    
    //Exit stage right!
    return 0;
}