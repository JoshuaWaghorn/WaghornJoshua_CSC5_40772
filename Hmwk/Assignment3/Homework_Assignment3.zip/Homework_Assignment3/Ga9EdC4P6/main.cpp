/* 
 * File:   Ga9EdC4P6
 * Author: Joshua Waghorn
 * Created on: 01/20/2020
 * Purpose: Scientists measure an 
 * object's mass in kilograms and 
 * its weight in newtons. If you 
 * know the amount of mass that an 
 * object has, you can calculate its 
 * weight, in newtons, with the following formula:
 * Weight = mass x 9.8
 * Write a program that asks the user to enter an object's mass, then calculates and displays its weight. If the object weighs more than 1000 newtons, display a message indicating that it is too heavy. If the object weighs less than 10 newtons, display a message indicating that the object is too light.
 * "The object is too heavy"
 * "The object is too light"
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    float weight, mass; 
    
    cout << "Enter the mass of an object:\n";
    cin>>mass;
    weight=mass*9.8;
    
    cout << fixed;
    if (weight<10)cout << "The object is too light";
    if (weight>1000)cout << "The object is too heavy";
    if (10<=weight&&weight<=1000)cout << "The object weighs " << setprecision (1) << weight << " newtons";


    //Exit stage right!
    return 0;
}