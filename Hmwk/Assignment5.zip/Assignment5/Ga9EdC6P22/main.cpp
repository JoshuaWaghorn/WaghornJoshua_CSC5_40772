/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 28, 2020, 11:14 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */

bool isPrime(int input);


int main(int argc, char** argv) {
    
    int input = 0;
    
    cout << "Enter a number:\n";
    cin>>input;
    
    if(isPrime(input)==true){
        cout << input << " is a prime number.";
    }
    
    else{
        cout << input << "is not a prime number.";
    }
    
   
    return 0;
}

bool isPrime(int input){
    if(input<1)return false;
    else if (input==1||input==2||input==3)return true;
    else{
        for(int a=2; a<input; a++){
            if(input%a==0)return false;
        }
        return true;
    }
}