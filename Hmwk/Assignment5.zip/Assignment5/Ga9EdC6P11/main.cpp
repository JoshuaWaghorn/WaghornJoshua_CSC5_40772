/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 28, 2020, 11:14 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;

void getScore(int &);
void calcAverage(int, int, int, int, int);
int findLowest(int, int, int, int, int);



int main() {
    int test1, test2, test3, test4, test5;
    
    for (int i = 0; i < 5; i++){if (i == 0) {getScore(test1);}
    else if (i == 1) {getScore(test2);}
    else if (i == 2) {getScore(test3);}
    else if (i == 3) {getScore(test4);}
    else if (i == 4) {getScore(test5);}
    }
    calcAverage(test1, test2, test3, test4, test5);
    return 0;

}



void getScore(int &score){
    int validscore;
    cout << "Enter a test score:\n";
    cin >> validscore;
    while (validscore<0||validscore>100) {
        cout << "Test scores values can only be between 0 and 100.\n"
                << "Please reenter the test score:\n";
        cin>>validscore;
    }
    score = validscore;
}



void calcAverage(int test1, int test2, int test3, int test4, int test5){
    int dropped = findLowest(test1, test2, test3, test4, test5);
    int sum = test1 + test2 + test3 + test4 + test5 - dropped;
    double average = sum / 4.0;
    cout << setprecision(1) << fixed << showpoint;
    cout << "The average is " << average;
}



int findLowest(int test1, int test2, int test3, int test4, int test5) {
    int lowest;
    if (test1 <= test2)lowest = test1;
    else lowest = test2;
    if (test3 < lowest)lowest = test3;
    if (test4 < lowest)lowest = test4;
    if (test5 < lowest)lowest = test5;
    
    return lowest;
}