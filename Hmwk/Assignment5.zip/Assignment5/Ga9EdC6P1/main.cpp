/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 28, 2020, 11:14 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    double whole, markuppercent, markup, calculateRetail;
    cout << fixed << setprecision(2);
    cout << "Enter the wholesale cost:\n";
    cin>>whole;
    cout << "Enter the markup percentage:\n";
    cin>>markuppercent;
    markup=markuppercent/100*whole;
    calculateRetail=whole+markup;
    cout << "The retail price is $" << calculateRetail;
    

    return 0;
}

