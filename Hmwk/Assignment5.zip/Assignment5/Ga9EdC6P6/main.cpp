/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 28, 2020, 11:14 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */


int main(int argc, char** argv) {
    
    double mass, velocity, joules;
    
    
    cout << "Enter the object's mass:\n";
    cin>>mass;
    cout << "Enter the object's velocity:\n";
    cin>>velocity;
    joules=0.5*mass*velocity*velocity;
    cout << "The object has " << fixed << showpoint << setprecision (1) << joules << " Joules of energy.";
    
    return 0;
}