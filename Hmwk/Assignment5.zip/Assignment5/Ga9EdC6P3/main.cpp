/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 28, 2020, 11:14 AM
 */

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

/*
 * 
 */

void findHighest(float nesales, float nwsales, float sesales, float swsales);
float getSales(string);

int main(int argc, char** argv) {
    
    float nesales, sesales, nwsales, swsales;
    
    
    nesales = getSales("Northeast");
    sesales = getSales("Southeast");
    nwsales = getSales("Northwest");
    swsales = getSales("Southwest");
    
    findHighest(nesales, sesales, nwsales, swsales);
    return 0;
}

float getSales(string Division){
    float sales;
    
    do
    {
        cout << "Enter the sales for " << Division << " division:$\n";
        cin>>sales;
        
        if(sales<0.00)
            cout << "Invalid entry.";
        
    }while(!(sales>0.00));
    return sales;
}



void findHighest(float nesales, float sesales, float nwsales, float swsales){
    float highest;
    cout << "The ";
    
    if (nesales > sesales && nesales > nwsales && nesales > swsales){
        highest = nesales;
        cout << "Northeast ";
    }
    else if (nwsales > sesales && nwsales > nesales && nwsales > swsales){
        highest = nwsales;
        cout << "Northwest ";
    }
    else if (sesales > nesales && sesales > nwsales && sesales > swsales){
        highest = sesales;
        cout << "Southeast ";
    }
    else if (swsales > sesales && swsales > nwsales && swsales > nesales){
        highest = swsales;
        cout << "Southwest ";
    }
    
    
    cout << fixed << showpoint << setprecision (2) << "division had the highest sales of $" << highest;
}
