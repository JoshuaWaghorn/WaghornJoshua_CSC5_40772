/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on January 25, 2020, 20:43
 */

#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

double hat (double w, double h);
double jacket (double w, double h, int a);
double waist (double w, double h, int a);
int main ()

{
double height;
double weight;
int age;
char yesno;
do{

cout << "Enter height(inches):\n" << endl;
cin >> height;
cout << "Enter Weight(pounds):\n" << endl;
cin >> weight;
cout << "Enter age:\n" << endl;
cin >> age;
cout << "Hat size is = " << fixed << setprecision(1) << hat(weight, height) << endl;
cout << "Jacket size = " << setprecision(1) << jacket(weight, height, age) << endl;
cout << "Waist size = " << setprecision(1) << waist(weight, height, age) << endl;

cout << "Run again:\n" << endl;
cin >> yesno;
}
while (yesno == 'y'|| yesno == 'Y');

return 0;
} 

double hat (double w, double h)
{
double r;
r = (w / h)*2.9;
return (r);
}

double jacket (double w, double h, int a)
{
double r;
r = (w*h) / 288;
if (a >= 30 && a < 40)
	r = r + .125;
else if (a >= 40 && a < 50)
	r = r + .25;
else if (a >= 50 && a < 60)
	r = r + .375;
else if (a >= 60 && a < 70)
	r = r + .5;
else if (a >= 70 && a < 80)
	r = r + .625;
else if (a >= 80 && a < 90)
	r = r + .75;
else if (a >= 90 && a < 100)
	r = r + .875;
return (r);
}

double waist (double w, double h, int a)
{
double r;
r = w/5.7 + (a>28?(a-28)/2:0*.1); 
return (r);
}