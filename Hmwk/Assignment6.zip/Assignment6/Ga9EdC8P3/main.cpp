/* 
 * File:   Ga9EdC8P3
 * Author: Joshua Waghorn
 * Created on 2/8/2020 1900
 * Purpose:  Lottery numbers with binary
 */

//System Libraries
#include <iostream>

using namespace std;

//Function Prototypes
bool match(const int [], int, int);

int main()
{
    int numbers[10] = {13579, 26791, 26792, 33445, 55555,
                             62483, 77777, 79422, 85647, 93121};
    int winnum;
    
    cout << "Enter the winning number:\n";
    cin >> winnum;
    
    if(match(numbers, 10, winnum))
        cout << "Congratulations you have won!";
    else
        cout << "No winning numbers.";
    
    return 0;
}

bool match(const int numbers[], int size, int winnum){
    int first=0,last=size-1,middle;
    while(first<=last){
        
        middle=(first+last)/2;
        
        if(numbers[middle]==winnum){
            return true;
        }
        else if(numbers[middle]>winnum){
            last=middle-1;
        }
        else if(numbers[middle]<winnum){
            first=middle+1;
        }
    }
    
    return false;
}