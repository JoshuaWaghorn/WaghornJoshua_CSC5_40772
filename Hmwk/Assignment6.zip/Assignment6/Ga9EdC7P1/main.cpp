/* 
 * File:   Ga9EdC7P1
 * Author: Joshua Waghorn
 * Created on 2/7/2020 1100
 * Purpose:  Ten values in an array
 */

//System Libraries
#include <iostream>

using namespace std;
//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
     //Declare Variable Data Types and Constants
    const int size = 10;
    int small, large;
    int numarray[size];
    
    //Process or map Inputs to Outputs
    cout<<"Enter 10 integers:\n";
    for(int i=0;i<size;i++){
        cin>>numarray[i];
    }
    small=numarray[0];
    large=numarray[0];
    
    for(int j=0;j<size;j++){
        if(numarray[j]>large)
            large=numarray[j];
        if(numarray[j]<small)
            small=numarray[j];
    }
        //Display Outputs
        cout<<large<<" is the highest number.\n";
        cout<<small<<" is the lowest number.";
        
    //Exit stage right!
    return 0;
}

