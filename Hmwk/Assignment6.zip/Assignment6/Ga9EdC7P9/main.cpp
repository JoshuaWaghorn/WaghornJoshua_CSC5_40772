/* 
 * File:   Ga9EdC7P9
 * Author: Joshua Waghorn
 * Created on 2/8/2020 1800
 * Purpose:  Calculate Employee gross pay
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main(){
    const int size = 7;
    long empId[size] = {5658845, 4520125, 7895122, 
                        8777541, 8451277, 1302850,
                        7580489};
    int hours[size];
    double payRate[size];
    double wages[size];
    
    for(int i=0; i < size; i++){
        cout<<"Enter employee "<<empId[i]<<"'s pay rate:\n";
        cin>>payRate[i];
        
        cout<<"Enter employee "<<empId[i]<<"'s hours work:\n";
        cin>>hours[i];
        
        wages[i] = hours[i] * payRate[i];
    }
    
    for(int i=0; i < size; i++){
        cout<<fixed<<showpoint<<setprecision(2);
        cout<<"Employee "<<empId[i]<<"'s gross pay $"<<wages[i]<<endl;
    }
    
    return 0;
}