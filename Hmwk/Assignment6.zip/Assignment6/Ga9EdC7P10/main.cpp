/* 
 * File:   Ga9EdC7P10
 * Author: Joshua Waghorn
 * Created on 2/8/2020 1700
 * Purpose:  Driver's License Office test correction
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

int numcorrect(char answer[],const char anskey[], 
                   const int size);
void outwrong(char answer[],const char anskey[], 
                   const int size);


//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const int size=20;
    const char anskey[size]={
        'A','D','B','B','C',
        'B','A','B','C','D',
        'A','C','D','B','D',
        'C','C','A','D','B'
    };
    char answer[size];
    int correct;
    
    //Initialize Variables
    
    //Process or map Inputs to Outputs
    cout<<"Enter the student's test answers:\n";
    for(int i=0;i<size;i++){
        cin>>answer[i];
        while (answer[i]<'A'||answer[i]>'D'){
            cin>>answer[i];
        }
    }
    
    correct = numcorrect(answer,anskey,size);
    
    if(correct>=15){
        cout<<"The student passed.\n";
    }else{
        cout<<"The student failed.\n";
    }
    
    cout<<"There were "<<correct<<" correct answers.\n";
    cout<<"There were "<<size-correct<<" incorrect answers.\n";
    if(correct<20){
        cout<<"Incorrect questions:\n";
        outwrong(answer,anskey,size);
    }else{
        cout<<"No questions were answered incorrectly.\n";
    }
    
    
    
    //Display Outputs
    

    //Exit stage right!
    return 0;
}


int numcorrect(char answer[],const char anskey[],const int size){
    int right=0;
    for(int i=0;i<size;i++){
        if(answer[i]==anskey[i]){
            right++;
        }
    }
    return right;
}

void outwrong(char answer[],const char anskey[],const int size){
    for(int i=0;i<size;i++){
        if(answer[i]!=anskey[i]){
            cout<<i+1<<endl;
        }
    }
}