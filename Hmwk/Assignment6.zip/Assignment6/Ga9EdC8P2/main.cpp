/* 
 * File:   Ga9EdC8P2
 * Author: Joshua Waghorn
 * Created on 2/8/2020 1830
 * Purpose:  Lottery chances
 */

//System Libraries
#include <iostream>
using namespace std;

//Function Prototypes
bool match(const int [], int, int);

int main()
{
    int numbers[10] = {13579, 26791, 26792, 33445, 55555,
                             62483, 77777, 79422, 85647, 93121};
    
    int winnum;
    cout << "Enter the winning number:\n";
    cin >> winnum;
    
    if(match(numbers, 10, winnum))
        cout << "Congratulations you have won!";
    else
        cout << "No winning numbers.";
    
    return 0;
}

bool match(const int numbers[], int size, int winnum){
    for(int count=0; count<size; count++){
        if(numbers[count]==winnum)
            return true;
    }
    return false;
}