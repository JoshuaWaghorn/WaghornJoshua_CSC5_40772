/* 
 * File:   main.cpp
 * Author: Joshua Waghorn
 *
 * Created on February 7, 2020, 1:05 PM
 */

#include <iostream>

using namespace std;

char board[3][3]; //Declare global array
int i,j,k=0,loc1,loc2,control=0; //Declare global variables
void start();
void show();
int getIndex(int );
void check();
void getInput();
int moreInput();
void start() //Define start function
{
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
board[i][j]='*'; //Put * initially to your array
}
}
}
void show() //Show your array
{
//system("CLS");
//cout<<"Player 1---- X"<<endl<<"Player 2---- O"<<endl<<endl;
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
cout<<board[i][j]<<" "; //Print array
}
cout<<endl;
}
}
int getIndex(int l) //this function returns the index of the user input location
{
int matchIndex=0, f=0;
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
matchIndex++;
if(l==matchIndex)
{
loc1=i;
loc2=j;
f=1;
break;
}
}
}
if(f==0)
loc1=11;
}
void check() //checks wheather user wins or not
{
int won=0;
if(board[0][0]==board[1][1] && board[1][1]==board[2][2])
{
won=1;
i=0;j=0;
}
else if(board[0][0]==board[0][1] && board[0][2]==board[0][1])
{
won =1;
i=0;j=0;
}
else if(board[0][0]==board[1][0] && board[1][0]==board[2][0])
{
won =1;
i=0;j=0;
}
else if(board[1][0]==board[1][1] && board[1][1]==board[1][2])
{
won =1;
i=1;j=0;
}
else if(board[2][0]==board[2][1] && board[2][1]==board[2][2])
{
won =1;
i=2;j=0;
}
else if(board[0][2]==board[1][2] && board[1][2]==board[2][2])
{
won =1;
i=2;j=2;
}
if(won==1)
{
char word=board[i][j];
if(word=='X')
{
cout<<endl<<"Player 1 won"<<endl;
control=1;
}
else if(word=='O')
{
cout<<endl<<"Player 2 won"<<endl;
control=1;
}
else
show();
}
}
void getInput() //Ask for input from user
{
int loc,flag=0;
char symbol;
if(k%2==0) //each time k has different value. it differentiate between users
{
flag=1;
symbol='X';
}
else
{
flag=2;
symbol='O';
}
k++;
do{
cout<<"Enter Location Player "<<flag<<":("<<symbol<<") (1-9)\t";
cin>>loc;
getIndex(loc); // i & j are global variables now they will be containing the location
if(loc1==11)
loc=11;
if(board[loc1][loc2]=='*')
board[loc1][loc2]=symbol;
else
{
cout<<"This location is filled. Chose another\n";
loc=11;
}
}while(loc<1 || loc >9);
show();
check();
}
int moreInput() 
{
int ch=1;
for(i=0;i<3;i++)
{
for(j=0;j<3;j++)
{
if(board[i][j]=='*')
{
ch=0;
break;
}
}
}
return(ch);
}
int main()
{
start();
show();
do{
getInput();
if(control==0)
control=moreInput();
if(control)
break;
}while(control==0);
cout<<endl<<"Game over"<<endl;
}

