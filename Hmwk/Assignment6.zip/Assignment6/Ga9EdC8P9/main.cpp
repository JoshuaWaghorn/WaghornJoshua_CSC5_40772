/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
void selectionSort();
void binarySearch();
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    int arr1 []={
            81,36,37,85,52,70,38,55,31,37,
            27,58,32,40,99,79,92,31,32,64,
            92,35,85,66,27,67,23,11,91,88,
            17,18,71,49,13,82,68,82,23,12
    };
    int arr2 []={
            81,36,37,85,52,70,38,55,31,37,
            27,58,32,40,99,79,92,31,32,64,
            92,35,85,66,27,67,23,11,91,88,
            17,18,71,49,13,82,68,82,23,12
    };
    //Declare Variable Data Types and Constants

    //Initialize Variables
    
    //Process or map Inputs to Outputs
    
    
    
    
    
    
    
    
    
    
    
    
    //Display Outputs

    //Exit stage right!
    return 0;
}

int binarySearch(const int arr1[], int numElems, int value){
        int first = 0, last = numElems-1, middle, position=-1;
        bool found = false;
        
        while (!found&&first<=last){
            middle=first+last/2;
            if(arr1[middle]==value){
                found = true;
                position = middle;
            }
            else if (arr1[middle]>value)
                last = middle - 1;
            else first = middle+1;
        }
        return position;
    }



int selectionSort(int numbers[], int arraySize){
    
    int exchangeCounter = 1;

    
    int startScan, minValue, minIndex;
    int start, end;

    
    for(startScan = start; startScan < arraySize-1; startScan++){
        
        minValue = numbers[startScan];
        minIndex = startScan;
        
        for(int index = startScan+1; index < arraySize; index++){
            
            if(numbers[index] < minValue){
                
                minValue = numbers[index];
                minIndex = index;
            }
        } 
        if(minIndex == startScan)
            continue;
       
        numbers[minIndex] = numbers[startScan];
        
        numbers[startScan] = minValue;
       
        exchangeCounter++;
    }
    return exchangeCounter;
}