/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const int size=5;
    float sold[size];
    float total;
    string salsas[size]={
        "mild","medium","sweet","hot","zesty"
    };
    
    cout<<"Enter the sales of "<<salsas[0]<<" salsa:$";
    cin>>sold[0];
    cout<<endl;
    cout<<"Enter the sales of "<<salsas[1]<<" salsa:$";
    cin>>sold[1];
    cout<<endl;
    cout<<"Enter the sales of "<<salsas[2]<<" salsa:$";
    cin>>sold[2];
    cout<<endl;
    cout<<"Enter the sales of "<<salsas[3]<<" salsa:$";
    cin>>sold[3];
    cout<<endl;
    cout<<"Enter the sales of "<<salsas[4]<<" salsa:$";
    cin>>sold[4];
    cout<<endl;
    
    cout<<"Type     Sales\n";
    cout<<salsas[0]<<"     $"<<sold[0]<<endl;
    cout<<salsas[1]<<"   $"<<sold[1]<<endl;
    cout<<salsas[2]<<"    $"<<sold[2]<<endl;
    cout<<salsas[3]<<"      $"<<sold[3]<<endl;
    cout<<salsas[4]<<"    $"<<sold[4]<<endl;
    
    total=sold[0]+sold[1]+sold[2]+sold[3]+sold[4];
    cout<<"Total Sales was $"<<total<<endl;
    
    if(sold[0]<sold[1]&&sold[0]<sold[2]&&sold[0]<sold[3]&&sold[0]<sold[4]){
        cout<<salsas[0]<<" was the lowest selling product.\n";
    }
    else if(sold[1]<sold[0]&&sold[1]<sold[2]&&sold[1]<sold[3]&&sold[1]<sold[4]){
        cout<<salsas[1]<<" was the lowest selling product.\n";
    }
    else if(sold[2]<sold[1]&&sold[2]<sold[0]&&sold[2]<sold[3]&&sold[2]<sold[4]){
        cout<<salsas[2]<<" was the lowest selling product.\n";
    }
    else if(sold[3]<sold[1]&&sold[3]<sold[2]&&sold[3]<sold[0]&&sold[3]<sold[4]){
        cout<<salsas[3]<<" was the lowest selling product.\n";
    }
    else {
        cout<<salsas[4]<<" was the lowest selling product.\n";
    }
    
    if(sold[0]>sold[1]&&sold[0]>sold[2]&&sold[0]>sold[3]&&sold[0]>sold[4]){
        cout<<salsas[0]<<" was the highest selling product.";
    }
    else if(sold[1]>sold[0]&&sold[1]>sold[2]&&sold[1]>sold[3]&&sold[1]>sold[4]){
        cout<<salsas[1]<<" was the highest selling product.";
    }
    else if(sold[2]>sold[1]&&sold[2]>sold[0]&&sold[2]>sold[3]&&sold[2]>sold[4]){
        cout<<salsas[2]<<" was the highest selling product.";
    }
    else if(sold[3]>sold[1]&&sold[3]>sold[2]&&sold[3]>sold[0]&&sold[3]>sold[4]){
        cout<<salsas[3]<<" was the highest selling product.";
    }
    else {
        cout<<salsas[4]<<" was the highest selling product.";
    }
    
    //Exit stage right!
    return 0;
}